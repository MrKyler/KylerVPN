package com.v2ray.ang.ui.quick

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.enums.PermissionType
import com.v2ray.ang.ui.base.HelperBaseComponentActivity
import com.v2ray.ang.ui.main.MainActivity

/**
 * Launcher screen: one big button, automatic choice of the fastest server,
 * ping and speed of the connected server, quick server switching.
 * The full v2rayNG interface stays available through the "Расширенные" button.
 */
class QuickActivity : HelperBaseComponentActivity() {

    private val viewModel: QuickViewModel by viewModels()

    /** Action to run once the system VPN permission dialog has been accepted. */
    private var afterVpnPermission: (() -> Unit)? = null

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val action = afterVpnPermission
            afterVpnPermission = null
            if (result.resultCode == RESULT_OK) action?.invoke()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkAndRequestPermission(PermissionType.POST_NOTIFICATIONS) {}
    }

    override fun onStart() {
        super.onStart()
        viewModel.reloadServerList()
    }

    @Composable
    override fun ScreenContent() {
        val state by viewModel.state.collectAsStateWithLifecycle()
        BackHandler { moveTaskToBack(false) }
        QuickScreen(
            state = state,
            onPowerClick = {
                when {
                    state.isBusy || state.isConnected -> viewModel.disconnect()
                    else -> withVpnPermission { viewModel.connectBest() }
                }
            },
            onNextServer = { withVpnPermission { viewModel.nextServer() } },
            onFindBest = { withVpnPermission { viewModel.connectBest(forceUpdate = true) } },
            onSpeedTest = viewModel::runSpeedTest,
            onSelectServer = { guid -> withVpnPermission { viewModel.selectServer(guid) } },
            onOpenAdvanced = { startActivity(Intent(this, MainActivity::class.java)) },
        )
    }

    /** Makes sure the VPN permission is granted, asking for it if necessary, then runs [action]. */
    private fun withVpnPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.CINNAMON_BUN) {
            checkAndRequestPermission(PermissionType.ACCESS_LOCAL_NETWORK) {}
        }
        val intent = VpnService.prepare(this)
        if (intent == null) {
            action()
        } else {
            afterVpnPermission = action
            vpnPermissionLauncher.launch(intent)
        }
    }
}
