package com.v2ray.ang.ui.quick

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val ColorOn = Color(0xFF2E9E5B)
private val ColorOff = Color(0xFF6B6B70)
private val ColorBusy = Color(0xFFF97910)
private val ColorError = Color(0xFFC62828)
private val ColorPingGood = Color(0xFF2E9E5B)
private val ColorPingMid = Color(0xFFF97910)
private val ColorPingBad = Color(0xFFC62828)

@Composable
fun QuickScreen(
    state: QuickUiState,
    onPowerClick: () -> Unit,
    onNextServer: () -> Unit,
    onFindBest: () -> Unit,
    onSpeedTest: () -> Unit,
    onSelectServer: (String) -> Unit,
    onOpenAdvanced: () -> Unit,
) {
    var showServers by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = "Быстрый VPN",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                TextButton(onClick = onOpenAdvanced) { Text("Расширенные") }
            }

            Spacer(Modifier.height(28.dp))
            PowerButton(state = state, onClick = onPowerClick)
            Spacer(Modifier.height(18.dp))
            StatusText(state)
            Spacer(Modifier.height(24.dp))

            if (state.isConnected || (state.serverName != null && state.isBusy)) {
                ServerCard(state = state, onSpeedTest = onSpeedTest)
                Spacer(Modifier.height(16.dp))
            }

            val canAct = !state.isBusy
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedButton(
                    onClick = onNextServer,
                    enabled = canAct && (state.isConnected || state.serverCount > 0),
                    modifier = Modifier.weight(1f),
                ) { Text("Сменить сервер") }
                OutlinedButton(
                    onClick = onFindBest,
                    enabled = canAct,
                    modifier = Modifier.weight(1f),
                ) { Text("Найти лучший") }
            }
            TextButton(onClick = { showServers = true }, enabled = canAct) {
                Text("Список серверов (${state.serverCount})")
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = footerText(state),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
        }
    }

    if (showServers) {
        ServerListDialog(
            servers = state.servers,
            onDismiss = { showServers = false },
            onPick = {
                showServers = false
                onSelectServer(it)
            },
        )
    }
}

@Composable
private fun PowerButton(state: QuickUiState, onClick: () -> Unit) {
    val color = when (state.phase) {
        QuickPhase.CONNECTED -> ColorOn
        QuickPhase.ERROR -> ColorError
        QuickPhase.IDLE -> ColorOff
        else -> ColorBusy
    }
    val label = when {
        state.isBusy -> "Отменить подключение"
        state.isConnected -> "Отключить VPN"
        else -> "Подключить VPN"
    }
    Box(
        modifier = Modifier
            .size(190.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.16f))
            .padding(14.dp)
            .clip(CircleShape)
            .background(color)
            .clickable(onClickLabel = label, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (state.isBusy) {
            CircularProgressIndicator(
                modifier = Modifier.size(72.dp),
                color = Color.White,
                strokeWidth = 5.dp,
            )
        } else {
            PowerGlyph()
        }
    }
}

@Composable
private fun PowerGlyph() {
    Canvas(modifier = Modifier.size(76.dp)) {
        val strokeWidth = 8.dp.toPx()
        val stroke = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        val inset = strokeWidth / 2
        drawArc(
            color = Color.White,
            startAngle = -50f,
            sweepAngle = 280f,
            useCenter = false,
            topLeft = Offset(inset, size.height * 0.14f + inset),
            size = Size(size.width - strokeWidth, size.height * 0.86f - strokeWidth),
            style = stroke,
        )
        drawLine(
            color = Color.White,
            start = Offset(size.width / 2, inset),
            end = Offset(size.width / 2, size.height * 0.5f),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round,
        )
    }
}

@Composable
private fun StatusText(state: QuickUiState) {
    val (text, color) = when (state.phase) {
        QuickPhase.IDLE -> "Нажмите, чтобы подключиться к самому быстрому серверу" to
                MaterialTheme.colorScheme.onSurfaceVariant

        QuickPhase.CONNECTED -> "Подключено" to ColorOn
        QuickPhase.ERROR -> state.message to ColorError
        else -> state.message to MaterialTheme.colorScheme.onBackground
    }
    Text(
        text = text,
        fontSize = if (state.isConnected) 20.sp else 15.sp,
        fontWeight = if (state.isConnected) FontWeight.SemiBold else FontWeight.Normal,
        textAlign = TextAlign.Center,
        color = color,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun ServerCard(state: QuickUiState, onSpeedTest: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Сервер",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = state.serverName ?: "—",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface,
            )
            state.exitInfo?.let {
                Text(
                    text = "Выход в интернет: $it",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(14.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric(label = "Пинг", value = pingText(state.pingMillis), color = pingColor(state.pingMillis))
                Metric(label = "Загрузка ↓", value = speedText(state.downBytesPerSec))
                Metric(label = "Отдача ↑", value = speedText(state.upBytesPerSec))
            }

            if (state.isConnected) {
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    val result = when {
                        state.speedTesting -> "Измеряю…"
                        state.speedTestMbps != null ->
                            String.format(Locale.getDefault(), "%.1f Мбит/с", state.speedTestMbps)

                        state.speedTestFailed -> "Не удалось измерить"
                        else -> "Скорость сервера не измерялась"
                    }
                    Text(
                        text = result,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Button(onClick = onSpeedTest, enabled = !state.speedTesting) {
                        Text("Тест скорости")
                    }
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, color: Color = MaterialTheme.colorScheme.onSurface) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = color)
        Text(text = label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ServerListDialog(
    servers: List<QuickServer>,
    onDismiss: () -> Unit,
    onPick: (String) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Серверы по пингу") },
        text = {
            if (servers.isEmpty()) {
                Text("Пока нет проверенных серверов. Нажмите «Подключить» или «Найти лучший» — приложение проверит все серверы из списка.")
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    items(servers, key = { it.guid }) { server ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(
                                    onClickLabel = "Подключиться к серверу",
                                    role = Role.Button,
                                ) { onPick(server.guid) }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = (if (server.selected) "✓ " else "") + server.name,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = if (server.selected) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier.weight(1f),
                            )
                            Text(
                                text = "${server.delayMillis} мс",
                                color = pingColor(server.delayMillis),
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(start = 12.dp),
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
    )
}

private fun pingText(ping: Long?): String = when {
    ping == null -> "…"
    ping < 0 -> "нет ответа"
    else -> "$ping мс"
}

private fun pingColor(ping: Long?): Color = when {
    ping == null -> Color.Unspecified
    ping < 0 -> ColorPingBad
    ping < 150 -> ColorPingGood
    ping < 400 -> ColorPingMid
    else -> ColorPingBad
}

private fun speedText(bytesPerSec: Long): String {
    val kb = bytesPerSec / 1024.0
    return when {
        kb < 1 -> "0 КБ/с"
        kb < 1024 -> String.format(Locale.getDefault(), "%.0f КБ/с", kb)
        else -> String.format(Locale.getDefault(), "%.1f МБ/с", kb / 1024.0)
    }
}

private fun footerText(state: QuickUiState): String {
    val count = "Серверов в списке: ${state.serverCount}"
    val updated = if (state.listUpdatedAt > 0) {
        val minutes = ((System.currentTimeMillis() - state.listUpdatedAt) / 60_000).coerceAtLeast(0)
        val ago = when {
            minutes < 1 -> "только что"
            minutes < 60 -> "$minutes мин назад"
            else -> "${minutes / 60} ч назад"
        }
        "обновлён $ago"
    } else {
        "ещё не загружался"
    }
    return "$count · $updated\nСписок обновляется автоматически каждый час"
}
