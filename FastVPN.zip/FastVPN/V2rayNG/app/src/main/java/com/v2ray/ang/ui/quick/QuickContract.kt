package com.v2ray.ang.ui.quick

/** Stage of the one-button connect flow. */
enum class QuickPhase {
    /** VPN is off. */
    IDLE,

    /** Downloading the fresh server list. */
    UPDATING,

    /** Measuring latency of all servers. */
    TESTING,

    /** Starting the tunnel through the chosen server. */
    CONNECTING,

    /** Tunnel is up, verifying that the internet really works through it. */
    CHECKING,

    /** Connected and verified. */
    CONNECTED,

    /** Something went wrong; [QuickUiState.message] explains what. */
    ERROR,
}

data class QuickServer(
    val guid: String,
    val name: String,
    val delayMillis: Long,
    val selected: Boolean,
)

data class QuickUiState(
    val phase: QuickPhase = QuickPhase.IDLE,
    /** Progress or error text shown under the button. */
    val message: String = "",
    val serverGuid: String? = null,
    val serverName: String? = null,
    /** Latency through the tunnel in ms; null = not measured yet, negative = failed. */
    val pingMillis: Long? = null,
    /** "(DE) 1.2.3.4" — where the traffic leaves to the internet. */
    val exitInfo: String? = null,
    val downBytesPerSec: Long = 0,
    val upBytesPerSec: Long = 0,
    val speedTesting: Boolean = false,
    /** Result of the last download test through the tunnel, Mbit/s. */
    val speedTestMbps: Double? = null,
    val speedTestFailed: Boolean = false,
    val serverCount: Int = 0,
    val listUpdatedAt: Long = 0L,
    val servers: List<QuickServer> = emptyList(),
) {
    val isBusy: Boolean
        get() = phase == QuickPhase.UPDATING ||
                phase == QuickPhase.TESTING ||
                phase == QuickPhase.CONNECTING ||
                phase == QuickPhase.CHECKING

    val isConnected: Boolean get() = phase == QuickPhase.CONNECTED
}
