package com.v2ray.ang.ui.quick

import android.app.Application
import android.net.TrafficStats
import android.os.Process
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.v2ray.ang.AngApplication
import com.v2ray.ang.AppConfig
import com.v2ray.ang.core.LauncherManager
import com.v2ray.ang.dto.ConnectionTestResult
import com.v2ray.ang.dto.TestServiceMessage
import com.v2ray.ang.dto.UrlContentRequest
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.handler.AngConfigManager
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.handler.SettingsManager
import com.v2ray.ang.handler.SubscriptionUpdater
import com.v2ray.ang.ui.main.MainRepository
import com.v2ray.ang.ui.main.MainServiceEvent
import com.v2ray.ang.util.HttpUtil
import com.v2ray.ang.util.LogUtil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Logic of the one-button screen:
 *  1. keep the server list fresh (hourly in background + on demand),
 *  2. measure all servers and pick the one with the lowest real latency,
 *  3. start the tunnel, verify that the internet works through it, otherwise try the next server,
 *  4. while connected show ping, live speed and allow switching servers.
 *
 * All heavy lifting (config building, Xray core, VPN service, latency probes) is done by the
 * existing v2rayNG engine; this class only orchestrates it.
 */
class QuickViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AngApplication
    private val repo = MainRepository(app)

    private val _state = MutableStateFlow(QuickUiState())
    val state: StateFlow<QuickUiState> = _state.asStateFlow()

    @Volatile
    private var tunnelRunning = false
    private var pipelineJob: Job? = null
    private var monitorJob: Job? = null
    private var speedJob: Job? = null

    /** Servers that did not work during this session; skipped when picking the next one. */
    private val failedGuids = HashSet<String>()
    private var autoSwitches = 0

    private var startWaiter: CompletableDeferred<Boolean>? = null
    private var lastStartError: String? = null
    private val delayWaiters = ConcurrentHashMap<String, CompletableDeferred<ConnectionTestResult?>>()

    private var testRequestId: String? = null
    private val testResults = ConcurrentHashMap<String, Long>()
    private var testDone: CompletableDeferred<Unit>? = null

    init {
        ensureSubscription()
        refreshMeta()
        viewModelScope.launch {
            repo.mainServiceEvent.collect { handleEvent(it) }
        }
        startSpeedSampler()
        // Hourly background refresh of the list (KEEP policy: does not reset an existing schedule).
        runCatching { SubscriptionUpdater.sync(app) }
    }

    // ------------------------------------------------------------------ public actions

    /** Big button while disconnected: refresh list if needed, find the fastest server, connect. */
    fun connectBest(forceUpdate: Boolean = false) {
        if (pipelineJob?.isActive == true) return
        failedGuids.clear()
        autoSwitches = 0
        launchPipeline { findAndConnect(forceUpdate) }
    }

    /** Switch to the next best server (the current one is skipped). */
    fun nextServer() {
        if (pipelineJob?.isActive == true) return
        autoSwitches = 0
        launchPipeline {
            MmkvManager.getSelectServer()?.let { failedGuids.add(it) }
            val next = rankedGuids().firstOrNull()
            if (next != null) {
                connectTo(next, auto = true)
            } else {
                // Every known server was tried: start over with a fresh measurement.
                failedGuids.clear()
                MmkvManager.getSelectServer()?.let { failedGuids.add(it) }
                findAndConnect(forceUpdate = false)
            }
        }
    }

    /** Connect to a server picked manually from the list. */
    fun selectServer(guid: String) {
        if (pipelineJob?.isActive == true) return
        autoSwitches = 0
        launchPipeline { connectTo(guid, auto = false) }
    }

    fun disconnect() {
        pipelineJob?.cancel()
        pipelineJob = null
        abortTest()
        startWaiter?.complete(false)
        stopMonitor()
        LauncherManager.stopService(app)
        _state.update {
            it.copy(
                phase = QuickPhase.IDLE,
                message = "",
                pingMillis = null,
                exitInfo = null,
                downBytesPerSec = 0,
                upBytesPerSec = 0,
                speedTestMbps = null,
                speedTestFailed = false,
                speedTesting = false,
            )
        }
    }

    /** Re-measure latency of the current connection right now. */
    fun refreshPingNow() {
        if (!tunnelRunning || pipelineJob?.isActive == true) return
        viewModelScope.launch { refreshPing() }
    }

    /** Download a test file through the tunnel and show the achieved speed. */
    fun runSpeedTest() {
        if (!tunnelRunning || speedJob?.isActive == true) return
        speedJob = viewModelScope.launch {
            _state.update { it.copy(speedTesting = true, speedTestMbps = null, speedTestFailed = false) }
            val mbps = withContext(Dispatchers.IO) { downloadSpeedMbps() }
            _state.update {
                it.copy(speedTesting = false, speedTestMbps = mbps, speedTestFailed = mbps == null)
            }
        }
    }

    fun reloadServerList() = refreshMeta()

    // ------------------------------------------------------------------ pipeline

    private fun launchPipeline(block: suspend () -> Unit) {
        pipelineJob = viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                LogUtil.e(AppConfig.TAG, "QuickViewModel pipeline failed", e)
                fail("Ошибка: ${e.message ?: e.javaClass.simpleName}", stopTunnel = true)
            } finally {
                startWaiter = null
            }
        }
    }

    private suspend fun findAndConnect(forceUpdate: Boolean) {
        setPhase(QuickPhase.UPDATING, "Обновляю список серверов…")
        val count = withContext(Dispatchers.IO) { refreshServerList(forceUpdate) }
        refreshMeta()
        if (count == 0) {
            fail(
                "Не удалось загрузить список серверов. Проверьте интернет и попробуйте ещё раз.",
                stopTunnel = false,
            )
            return
        }

        setPhase(QuickPhase.TESTING, "Ищу самый быстрый сервер…")
        val ranked = testServers()
        refreshMeta()
        if (ranked.isEmpty()) {
            fail(
                "Ни один сервер не ответил. Список обновляется каждый час — попробуйте чуть позже.",
                stopTunnel = false,
            )
            return
        }
        connectTo(ranked.first(), auto = true)
    }

    private suspend fun connectTo(guid: String, auto: Boolean) {
        val name = nameOf(guid)
        _state.update {
            it.copy(
                phase = QuickPhase.CONNECTING,
                message = "Подключаюсь: $name",
                serverGuid = guid,
                serverName = name,
                pingMillis = null,
                exitInfo = null,
                speedTestMbps = null,
                speedTestFailed = false,
            )
        }
        stopMonitor()
        MmkvManager.setSelectServer(guid)

        val waiter = CompletableDeferred<Boolean>()
        startWaiter = waiter
        lastStartError = null
        LauncherManager.restartServiceOrStart(app) { LauncherManager.startService(app) }
        val started = withTimeoutOrNull(START_TIMEOUT_MS) { waiter.await() } ?: false
        startWaiter = null
        if (!started) {
            failedGuids.add(guid)
            tryNextOrFail(auto, lastStartError ?: "Не удалось запустить VPN через «$name».")
            return
        }

        setPhase(QuickPhase.CHECKING, "Проверяю интернет через «$name»…")
        delay(700)
        var result: ConnectionTestResult? = null
        for (attempt in 1..3) {
            result = measureDelay()
            if (result != null) break
            delay(1000)
        }
        if (result != null && result.delayMillis >= 0) {
            onVerified(guid, result)
            return
        }
        failedGuids.add(guid)
        tryNextOrFail(auto, "Сервер «$name» не пропускает трафик.")
    }

    private suspend fun tryNextOrFail(auto: Boolean, reason: String) {
        if (!auto) {
            fail("$reason Выберите другой сервер.", stopTunnel = true)
            return
        }
        if (autoSwitches >= MAX_AUTO_SWITCHES) {
            fail(
                "$reason Автоматически подобрать рабочий сервер не удалось — нажмите «Найти лучший» ещё раз.",
                stopTunnel = true,
            )
            return
        }
        val next = rankedGuids().firstOrNull()
        if (next == null) {
            fail("$reason Больше нет проверенных серверов — нажмите «Найти лучший».", stopTunnel = true)
            return
        }
        autoSwitches++
        connectTo(next, auto = true)
    }

    private fun onVerified(guid: String, result: ConnectionTestResult) {
        _state.update {
            it.copy(
                phase = QuickPhase.CONNECTED,
                message = "",
                serverGuid = guid,
                serverName = nameOf(guid),
                pingMillis = result.delayMillis,
                exitInfo = formatExit(result),
            )
        }
        refreshMeta()
        startMonitor()
    }

    private fun fail(message: String, stopTunnel: Boolean) {
        if (stopTunnel) LauncherManager.stopService(app)
        stopMonitor()
        _state.update {
            it.copy(
                phase = QuickPhase.ERROR,
                message = message,
                pingMillis = null,
                exitInfo = null,
                downBytesPerSec = 0,
                upBytesPerSec = 0,
            )
        }
        refreshMeta()
    }

    private fun setPhase(phase: QuickPhase, message: String) {
        _state.update { it.copy(phase = phase, message = message) }
    }

    // ------------------------------------------------------------------ server list

    private fun ensureSubscription() {
        val existing = MmkvManager.decodeSubscription(SUB_ID)
        if (existing == null) {
            MmkvManager.encodeSubscription(
                SUB_ID,
                SubscriptionItem(
                    remarks = SUB_NAME,
                    url = SOURCES.first(),
                    enabled = true,
                    autoUpdate = true,
                    updateInterval = 60L,
                ),
            )
        } else if (!existing.autoUpdate || existing.updateInterval != 60L || existing.url.isBlank()) {
            existing.autoUpdate = true
            existing.updateInterval = 60L
            if (existing.url.isBlank()) existing.url = SOURCES.first()
            MmkvManager.encodeSubscription(SUB_ID, existing)
        }
    }

    /** Blocking. Returns the number of servers available after the refresh. */
    private fun refreshServerList(force: Boolean): Int {
        ensureSubscription()
        val sub = MmkvManager.decodeSubscription(SUB_ID) ?: return 0
        val have = MmkvManager.decodeServerList(SUB_ID).size
        val age = System.currentTimeMillis() - sub.lastUpdated
        if (!force && have > 0 && sub.lastUpdated > 0 && age in 0 until STALE_AFTER_MS) return have

        var text: String? = null
        for (url in SOURCES) {
            text = download(url)
            if (text != null) break
        }

        if (text == null) {
            if (have > 0) return have // keep the old list, better than nothing
            text = runCatching {
                app.assets.open(BUNDLED_LIST).bufferedReader().use { it.readText() }
            }.getOrNull() ?: return 0
        }

        val (count, _) = AngConfigManager.importBatchConfig(text, SUB_ID, false)
        if (count > 0) {
            MmkvManager.decodeSubscription(SUB_ID)?.let {
                it.lastUpdated = System.currentTimeMillis()
                MmkvManager.encodeSubscription(SUB_ID, it)
            }
        }
        return MmkvManager.decodeServerList(SUB_ID).size
    }

    /** Tries the local proxy first (if the tunnel is up), then a direct request. */
    private fun download(url: String): String? {
        val ports = if (tunnelRunning) listOf(SettingsManager.getHttpPort(), 0) else listOf(0)
        for (port in ports) {
            val body = runCatching {
                HttpUtil.getUrlContentWithUserAgent(
                    UrlContentRequest(
                        url = url,
                        timeout = 12_000,
                        httpPort = port,
                        proxyUsername = SettingsManager.getSocksUsername(),
                        proxyPassword = SettingsManager.getSocksPassword(),
                    )
                )
            }.getOrNull()
            if (body != null && looksLikeServerList(body)) return body
        }
        return null
    }

    private fun looksLikeServerList(text: String): Boolean =
        text.contains("vless://") || text.contains("vmess://") ||
                text.contains("trojan://") || text.contains("ss://")

    // ------------------------------------------------------------------ latency tests

    /** Measures all servers; returns guids with a working latency, best first. */
    private suspend fun testServers(): List<String> {
        val guids = MmkvManager.decodeServerList(SUB_ID)
        if (guids.isEmpty()) return emptyList()
        withContext(Dispatchers.IO) { MmkvManager.clearAllTestDelayResults(guids) }
        testResults.clear()

        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Unit>()
        testRequestId = id
        testDone = done
        repo.sendMsg2TestService(
            TestServiceMessage(
                key = AppConfig.MSG_MEASURE_CONFIG_START,
                subscriptionId = SUB_ID,
                serverGuids = emptyList(),
                onlyTcp = false,
            ),
            id,
        )

        val started = SystemClock.elapsedRealtime()
        try {
            while (!done.isCompleted) {
                delay(400)
                val elapsed = SystemClock.elapsedRealtime() - started
                val working = testResults.values.count { it > 0 }
                _state.update {
                    it.copy(
                        message = "Проверено ${testResults.size} из ${guids.size} · рабочих: $working",
                    )
                }
                // Do not wait for the slowest stragglers once we clearly have good candidates.
                if (elapsed > TEST_SOFT_LIMIT_MS && working >= 3) break
                if (elapsed > TEST_HARD_LIMIT_MS) break
            }
        } finally {
            if (!done.isCompleted) repo.cancelAllPing()
            testRequestId = null
            testDone = null
        }
        return rankedGuids()
    }

    private fun abortTest() {
        if (testRequestId != null) {
            repo.cancelAllPing()
            testRequestId = null
            testDone?.complete(Unit)
            testDone = null
        }
    }

    private fun delayOf(guid: String): Long =
        testResults[guid] ?: MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L

    /** Working servers sorted by latency, without the ones that failed in this session. */
    private fun rankedGuids(): List<String> =
        MmkvManager.decodeServerList(SUB_ID)
            .asSequence()
            .filter { it !in failedGuids }
            .map { it to delayOf(it) }
            .filter { it.second > 0 }
            .sortedBy { it.second }
            .map { it.first }
            .toList()

    private suspend fun measureDelay(timeoutMs: Long = DELAY_TIMEOUT_MS): ConnectionTestResult? {
        val id = UUID.randomUUID().toString()
        val waiter = CompletableDeferred<ConnectionTestResult?>()
        delayWaiters[id] = waiter
        repo.testCurrentServerRealPing(id)
        val result = withTimeoutOrNull(timeoutMs) { waiter.await() }
        delayWaiters.remove(id)
        return result
    }

    private suspend fun refreshPing() {
        val result = measureDelay() ?: return
        _state.update {
            if (it.phase != QuickPhase.CONNECTED) it
            else it.copy(pingMillis = result.delayMillis, exitInfo = formatExit(result) ?: it.exitInfo)
        }
    }

    // ------------------------------------------------------------------ connection monitor

    private fun startMonitor() {
        monitorJob?.cancel()
        monitorJob = viewModelScope.launch {
            var bad = 0
            while (isActive) {
                delay(MONITOR_INTERVAL_MS)
                if (!tunnelRunning || pipelineJob?.isActive == true) continue
                val result = measureDelay() ?: continue
                if (result.delayMillis >= 0) {
                    bad = 0
                    autoSwitches = 0
                    _state.update {
                        if (it.phase != QuickPhase.CONNECTED) it
                        else it.copy(
                            pingMillis = result.delayMillis,
                            exitInfo = formatExit(result) ?: it.exitInfo,
                        )
                    }
                } else {
                    bad++
                    _state.update { if (it.phase == QuickPhase.CONNECTED) it.copy(pingMillis = -1) else it }
                    if (bad >= 3 && autoSwitches < MAX_AUTO_SWITCHES) {
                        bad = 0
                        val current = MmkvManager.getSelectServer()
                        launchPipeline {
                            if (current != null) failedGuids.add(current)
                            val next = rankedGuids().firstOrNull()
                            if (next == null) {
                                fail("Сервер перестал отвечать, запасных нет — нажмите «Найти лучший».", true)
                            } else {
                                autoSwitches++
                                connectTo(next, auto = true)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun stopMonitor() {
        monitorJob?.cancel()
        monitorJob = null
    }

    // ------------------------------------------------------------------ events from the VPN engine

    private fun handleEvent(event: MainServiceEvent) {
        when (event) {
            MainServiceEvent.StateRunning -> onTunnelState(true)
            MainServiceEvent.StateNotRunning -> onTunnelState(false)
            MainServiceEvent.StateStartSuccess -> {
                tunnelRunning = true
                val waiter = startWaiter
                if (waiter != null) waiter.complete(true) else onTunnelState(true)
            }

            is MainServiceEvent.StateStartFailure -> {
                tunnelRunning = false
                lastStartError = event.message
                val waiter = startWaiter
                if (waiter != null) waiter.complete(false) else onTunnelState(false)
            }

            MainServiceEvent.StateStopSuccess -> {
                tunnelRunning = false
                // While switching servers the tunnel is restarted: do not flash "disconnected".
                if (pipelineJob?.isActive != true) onTunnelState(false)
            }

            is MainServiceEvent.MeasureDelayResult ->
                delayWaiters.remove(event.requestId)?.complete(event.result)

            is MainServiceEvent.MeasureDelayCancelled ->
                delayWaiters.remove(event.requestId)?.complete(null)

            is MainServiceEvent.MeasureConfigSuccess -> {
                if (event.requestId == testRequestId) {
                    testResults[event.result.guid] = event.result.delayMillis
                }
            }

            is MainServiceEvent.MeasureConfigNotify -> Unit

            is MainServiceEvent.MeasureConfigFinish -> {
                if (event.requestId == testRequestId) testDone?.complete(Unit)
            }

            is MainServiceEvent.MeasureConfigCancelled -> {
                if (event.requestId == testRequestId) testDone?.complete(Unit)
            }
        }
    }

    /** Tunnel state reported by the engine while no connect flow of ours is in progress. */
    private fun onTunnelState(running: Boolean) {
        tunnelRunning = running
        if (pipelineJob?.isActive == true) return
        if (running) {
            val guid = MmkvManager.getSelectServer()
            _state.update {
                it.copy(
                    phase = QuickPhase.CONNECTED,
                    message = "",
                    serverGuid = guid,
                    serverName = guid?.let(::nameOf),
                )
            }
            startMonitor()
            viewModelScope.launch { refreshPing() }
        } else {
            stopMonitor()
            _state.update {
                it.copy(
                    phase = if (it.phase == QuickPhase.ERROR) QuickPhase.ERROR else QuickPhase.IDLE,
                    pingMillis = null,
                    exitInfo = null,
                    downBytesPerSec = 0,
                    upBytesPerSec = 0,
                )
            }
        }
    }

    // ------------------------------------------------------------------ speed

    /**
     * Live throughput of the tunnel. The Xray core runs inside this app's UID and the app is
     * excluded from the VPN, so the UID byte counters are exactly the encrypted traffic that
     * goes to the VPN server.
     */
    private fun startSpeedSampler() {
        viewModelScope.launch(Dispatchers.Default) {
            val uid = Process.myUid()
            var lastRx = TrafficStats.getUidRxBytes(uid)
            var lastTx = TrafficStats.getUidTxBytes(uid)
            var lastAt = SystemClock.elapsedRealtime()
            while (isActive) {
                delay(1000)
                val rx = TrafficStats.getUidRxBytes(uid)
                val tx = TrafficStats.getUidTxBytes(uid)
                val now = SystemClock.elapsedRealtime()
                val dt = (now - lastAt).coerceAtLeast(1)
                val down = if (rx >= 0 && lastRx >= 0) ((rx - lastRx) * 1000 / dt).coerceAtLeast(0) else 0L
                val up = if (tx >= 0 && lastTx >= 0) ((tx - lastTx) * 1000 / dt).coerceAtLeast(0) else 0L
                lastRx = rx
                lastTx = tx
                lastAt = now
                _state.update {
                    if (it.phase == QuickPhase.CONNECTED) {
                        it.copy(downBytesPerSec = down, upBytesPerSec = up)
                    } else if (it.downBytesPerSec != 0L || it.upBytesPerSec != 0L) {
                        it.copy(downBytesPerSec = 0, upBytesPerSec = 0)
                    } else {
                        it
                    }
                }
            }
        }
    }

    /** Blocking. Downloads a file through the local proxy for a few seconds; Mbit/s or null. */
    private fun downloadSpeedMbps(): Double? {
        val username = SettingsManager.getSocksUsername()
        val password = SettingsManager.getSocksPassword()
        val builder = OkHttpClient.Builder()
            .proxy(Proxy(Proxy.Type.HTTP, InetSocketAddress(AppConfig.LOOPBACK, SettingsManager.getHttpPort())))
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
        if (!username.isNullOrBlank() && !password.isNullOrBlank()) {
            builder.proxyAuthenticator { _, response ->
                if (response.request.header("Proxy-Authorization") != null) null
                else response.request.newBuilder()
                    .header("Proxy-Authorization", Credentials.basic(username, password))
                    .build()
            }
        }
        val client = builder.build()

        for (url in SPEED_TEST_URLS) {
            try {
                val request = Request.Builder().url(url).header("Cache-Control", "no-cache").build()
                client.newCall(request).execute().use { response ->
                    val body = response.body
                    if (!response.isSuccessful || body == null) return@use
                    val buffer = ByteArray(64 * 1024)
                    val input = body.byteStream()
                    val started = System.nanoTime()
                    var total = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        if (System.nanoTime() - started > SPEED_TEST_MAX_NANOS) break
                    }
                    val seconds = (System.nanoTime() - started) / 1e9
                    if (total > 200_000 && seconds > 0.2) return total * 8 / seconds / 1e6
                }
            } catch (e: Exception) {
                LogUtil.w(AppConfig.TAG, "Speed test via $url failed: ${e.message}")
            }
        }
        return null
    }

    // ------------------------------------------------------------------ helpers

    private fun nameOf(guid: String): String =
        MmkvManager.decodeServerConfig(guid)?.remarks?.takeIf { it.isNotBlank() } ?: guid.take(8)

    private fun formatExit(result: ConnectionTestResult): String? {
        val country = result.country?.takeIf { it.isNotBlank() }
        val ip = result.ipAddress?.takeIf { it.isNotBlank() }
        if (country == null && ip == null) return null
        return listOfNotNull(country?.let { "($it)" }, ip).joinToString(" ")
    }

    /** Re-reads list size, update time and the latency ranking from storage. */
    private fun refreshMeta() {
        viewModelScope.launch(Dispatchers.IO) {
            val sub = MmkvManager.decodeSubscription(SUB_ID)
            val all = MmkvManager.decodeServerList(SUB_ID)
            val selected = MmkvManager.getSelectServer()
            val ranking = all.mapNotNull { guid ->
                val d = delayOf(guid)
                if (d > 0) QuickServer(guid, nameOf(guid), d, guid == selected) else null
            }.sortedBy { it.delayMillis }
            _state.update {
                it.copy(
                    serverCount = all.size,
                    listUpdatedAt = sub?.lastUpdated?.takeIf { t -> t > 0 } ?: 0L,
                    servers = ranking,
                )
            }
        }
    }

    override fun onCleared() {
        pipelineJob?.cancel()
        monitorJob?.cancel()
        speedJob?.cancel()
        abortTest()
        runCatching { repo.close() }
        super.onCleared()
    }

    private companion object {
        /** Stable id so the subscription is created once and updated in place. */
        const val SUB_ID = "fastvpn-black-vless-rus-mobile"
        const val SUB_NAME = "BLACK VLESS RUS mobile"
        const val BUNDLED_LIST = "default_servers.txt"

        /** Primary source first; the CDN mirror is only a fallback (it can lag by hours). */
        val SOURCES = listOf(
            "https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/main/BLACK_VLESS_RUS_mobile.txt",
            "https://github.com/igareck/vpn-configs-for-russia/raw/main/BLACK_VLESS_RUS_mobile.txt",
            "https://cdn.jsdelivr.net/gh/igareck/vpn-configs-for-russia@main/BLACK_VLESS_RUS_mobile.txt",
        )

        val SPEED_TEST_URLS = listOf(
            "https://speed.cloudflare.com/__down?bytes=25000000",
            "https://proof.ovh.net/files/10Mb.dat",
            "http://speedtest.tele2.net/10MB.zip",
        )

        const val STALE_AFTER_MS = 50L * 60 * 1000
        const val START_TIMEOUT_MS = 20_000L
        const val DELAY_TIMEOUT_MS = 20_000L
        const val TEST_SOFT_LIMIT_MS = 25_000L
        const val TEST_HARD_LIMIT_MS = 60_000L
        const val MONITOR_INTERVAL_MS = 20_000L
        const val MAX_AUTO_SWITCHES = 4
        const val SPEED_TEST_MAX_NANOS = 8_000_000_000L
    }
}
